<?php

return [

    "sender_name"   => env("SMS_SENDER_NAME"),

    "username" 	    => env("SMS_USERNAME"),

    "password" 	    => env("SMS_PASSWORD"),

    "api_key"	    => env("SMS_API_KEY"),

    "callback_url"  => env("SMS_CALLBACK_URL"),

    "url_api_domain"  => env("SMS_URL_API_DOMAIN"),

];