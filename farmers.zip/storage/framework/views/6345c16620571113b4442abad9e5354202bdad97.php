<?php if($purchase->hasStatus("graded")): ?>
    <a href="javascript:void(0)"
       class="dropdown-item"
       onclick="event.preventDefault(); document.getElementById('completionForm<?php echo e($purchase->id); ?>').submit();"
    >
        <i class="fas fa-check-circle"></i> Complete
        <form id="completionForm<?php echo e($purchase->id); ?>"
              action="<?php echo e(route('purchases.completions.store', $purchase)); ?>"
              method="POST"
              class="d-none"
        >
            <?php echo csrf_field(); ?>
            <?php echo method_field("patch"); ?>
        </form>
    </a>
<?php endif; ?>