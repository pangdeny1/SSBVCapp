<?php

use Faker\Generator as Faker;

$factory->define(App\Harvest::class, function (Faker $faker) {
    return [
        //
    ];
});
