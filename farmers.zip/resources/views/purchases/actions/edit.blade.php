<a href="{{ route("purchases.edit", $purchase) }}" class="dropdown-item">
    <i class="far fa-edit"></i> Edit
</a>