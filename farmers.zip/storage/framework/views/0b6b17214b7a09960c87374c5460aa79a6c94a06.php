<?php $__env->startSection("content"); ?>
    <div class="wrapper">
        <div class="page has-sidebar">
            <div class="page-inner">
                <header class="page-title-bar">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active">
                                <a href="#">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i>Farmers</a>
                            </li>
                        </ol>
                    </nav>
                    <h1 class="page-title"> Edit Household </h1>
                </header>
                <div class="page-section">
                    <div class="row">
                        <div class="col-md-12">

                            <form action="<?php echo e(route("farmers.household_blocks.update",[$block->id, $farmer])); ?>"
                                  method="post"
                                  class="card border-0"
                            >
                                <?php echo csrf_field(); ?>
                                <header class="card-header border-bottom-0">
                                    Basic information
                                </header>
                                <div class="card-body">
                                    <div class="form-row">
                                        <div class="col-md-6 mb-3">
                                            <label for="number">Household Code</label>
                                            <input type="text"
                                                   name="number"
                                                   class="form-control <?php echo e($errors->has('number') ? 'is-invalid' : ''); ?>"
                                                   id="number"
                                                   value="<?php echo e(old("number",$block->number)); ?>"
                                            >
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-2 mb-3">
                                            <label for="size">Size</label>
                                            <input type="text"
                                                   name="size"
                                                   class="form-control <?php echo e($errors->has('size') ? 'is-invalid' : ''); ?>"
                                                   id="size"
                                                   value="<?php echo e(old("size",$block->size)); ?>"
                                            >
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="size_unit">Unit</label>
                                            <select name="size_unit"
                                                    class="custom-select d-block w-100 <?php echo e($errors->has('size_unit') ? 'is-invalid' : ''); ?>"
                                                    id="size_unit"
                                            >
                                                <option value="Hectare">Hectare</option>
                                            </select>
                                            <?php if($errors->has('size_unit')): ?>
                                                <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('size_unit')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-6 mb-3">
                                            <label for="farm_id">Farmland</label>
                                            <select name="farm_id"
                                                    class="form-control <?php echo e($errors->has('farm_id') ? 'is-invalid' : ''); ?>"
                                                    id="farm_id"
                                            >
                                                <option value="">Choose...</option>
                                                <?php $__currentLoopData = \App\Farm::where("farmer_id", $farmer->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($farm->id); ?>">
                                                    <?php echo e($farm->name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('farm_id')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('farm_id')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-6 mb-3">
                                            <label for="product_id">Crop</label>
                                            <select name="product_id"
                                                    class="form-control d-block w-100 <?php echo e($errors->has('product_id') ? 'is-invalid' : ''); ?>"
                                                    id="product_id"
                                                    required=""
                                            >
                                                <option value=""> Choose... </option>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($product->id); ?>" <?php echo e(old("product_id") === $product->id ? "selected" : ""); ?>>
                                                        <?php echo e($product->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('product_id')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('product_id')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <label for="description">Description</label>
                                            <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>"
                                                      name="description"
                                                      id="description"
                                                      placeholder="Type something...."
                                                      rows="5"
                                            ><?php echo e(old("description",$block->description)); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <hr class="mb-4">
                                    <div class="form-row">
                                        <button class="btn btn-primary btn-lg btn-block" type="submit">
                                            Update Changes
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="page-sidebar border-left bg-white">
                <header class="sidebar-header d-sm-none">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active">
                                <a href="#" onclick="Looper.toggleSidebar()">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i>Back</a>
                            </li>
                        </ol>
                    </nav>
                </header>
                <div class="sidebar-section">
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>