<?php $__env->startSection("content"); ?>
    <?php if($farmers->count()): ?>
        <div class="wrapper">
            <div class="page">
                <div class="page-inner">
                    <header class="page-title-bar">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route("home")); ?>">
                                        <i class="breadcrumb-icon fa fa-angle-left mr-2"></i> Dashboard
                                    </a>
                                </li>
                                <li class="breadcrumb-item active">
                                    Farmers
                                </li>
                            </ol>
                        </nav>
                        <div class="d-sm-flex align-items-sm-center">
                            <h1 class="page-title mr-sm-auto mb-0">
                                Farmers
                            </h1>
                            <div class="btn-toolbar">
                                <a href="" class="btn btn-light">
                                    <i class="oi oi-data-transfer-download"></i>
                                    <span class="ml-1">Export as excel</span>
                                </a>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("create", \App\Farmer::class)): ?>
                                <a href="<?php echo e(route("farmers.create")); ?>" class="btn btn-primary">
                                    <span class="fas fa-plus mr-1"></span>
                                    New farmer
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </header>

                    <div class="page-section">
                        <section class="card shadow-1 border-0 card-fluid">
                            <header class="card-header">
                                <ul class="nav nav-tabs card-header-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(request()->query("status") ? "" : "active"); ?>" href="<?php echo e(route("farmers.index")); ?>">
                                            All
                                        </a>
                                    </li>
                                </ul>
                            </header>

                            <div class="card-body">

                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <span class="oi oi-magnifying-glass"></span>
                                            </span>
                                        </div>
                                        <form action="">
                                            <input type="text" name="q" class="form-control" placeholder="Search record...">
                                        </form>
                                    </div>
                                </div>

                                <!-- .table-responsive -->

                                <div class="text-muted">  Showing <?php echo e($farmers->firstItem()); ?> to <?php echo e($farmers->lastItem()); ?> of <?php echo e($farmers->total()); ?> entries </div>

                                

                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                               <th>Farmer</th>
                                                <th>Gender</th>
                                                <th>Phone</th>
                                                <th>Email</th>
                                                <th>Group</th>
                                                <th>Region</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(route("farmers.show", $farmer)); ?>" class="user-avatar mr-1">
                                                        <img class="img-fluid"
                                                             src="<?php echo e(Avatar::create($farmer->full_name)->toBase64()); ?>"
                                                             alt="<?php echo e($farmer->full_name); ?>">
                                                    </a>
                                                    <a href="<?php echo e(route("farmers.show", $farmer)); ?>">
                                                        <?php echo e($farmer->full_name); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($farmer->gender); ?></td>
                                                <td><?php echo e($farmer->phone); ?></td>
                                                <td><?php echo e($farmer->email); ?></td>
                                                <td><?php echo e($farmer->groups->first()->name); ?></td>
                                                <td><?php echo e($farmer->address->state); ?></td>
                                                <td class="align-middle text-right">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("edit", \App\Farmer::class)): ?>
                                                    <a href="<?php echo e(route("farmers.edit", $farmer)); ?>" class="btn btn-sm btn-secondary">
                                                        <i class="fa fa-pencil-alt"></i>
                                                        <span class="sr-only">Edit</span>
                                                    </a>
                                                    <?php endif; ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("delete", \App\Farmer::class)): ?>
                                                    <a href="#" class="btn btn-sm btn-secondary">
                                                        <i class="far fa-trash-alt"></i>
                                                        <span class="sr-only">Remove</span>
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- .pagination -->
                                <?php echo e($farmers->links()); ?>

                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="wrapper">
            <!-- .empty-state -->
            <section id="notfound-state" class="empty-state">
                <!-- .empty-state-container -->
                <div class="empty-state-container">
                    <div class="state-figure">
                        <img class="img-fluid"
                             src="<?php echo e(asset("themes/looper/assets/images/illustration/img-7.png")); ?>"
                             alt=""
                             style="max-width: 300px"
                        >
                    </div>
                    <h3 class="state-header"> No Content, Yet. </h3>
                    <p class="state-description lead text-muted">
                        Use the button below to Register new .
                    </p>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("create", \App\Farmer::class)): ?>
                    <div class="state-action">
                        <a href="<?php echo e(route("farmers.create")); ?>" class="btn btn-primary">Register new</a>
                    </div>
                    <?php endif; ?>
                </div>
                <!-- /.empty-state-container -->
            </section>
            <!-- /.empty-state -->
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>