<?php $__env->startSection("content"); ?>
    <div class="wrapper">
        <div class="page">
            <div class="page-inner">
                <header class="page-title-bar">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route("home")); ?>">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i> Dashboard
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">
                                    Settings
                                </a>
                            </li>
                            <li class="breadcrumb-item active">
                                Blocks
                            </li>
                        </ol>
                    </nav>

                    <div class="d-sm-flex align-items-sm-center">
                        <h1 class="page-title mr-sm-auto mb-0"> Blocks </h1>
                        <div class="btn-toolbar">
                            <a href="<?php echo e(route("blocks.export")); ?>" class="btn btn-light">
                                <i class="far fa-file-excel"></i>
                                <span class="ml-1">Export as excel</span>
                            </a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("create", \App\Block::class)): ?>
                            <a href="<?php echo e(route("blocks.create")); ?>" class="btn btn-primary">
                                <span class="fas fa-plus mr-1"></span>
                                New block
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </header>
                <div class="page-section">
                    <section class="card card-fluid">
                        <header class="card-header">
                            <ul class="nav nav-tabs card-header-tabs">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query("status") ? "" : "active"); ?>"
                                       href="<?php echo e(route("blocks.index")); ?>"
                                    >
                                        All
                                    </a>
                                </li>
                            </ul>
                        </header>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <span class="oi oi-magnifying-glass"></span>
                                        </span>
                                    </div>
                                    <form action="">
                                        <input type="text" name="q" class="form-control" placeholder="Search record...">
                                    </form>
                                </div>
                            </div>

                            <div class="text-muted"> Showing <?php echo e($blocks->firstItem()); ?> to <?php echo e($blocks->lastItem()); ?> of <?php echo e($blocks->total()); ?> entries </div>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th class="text-left"  nowrap>Name</th>
                                        <th class="text-right" nowrap></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>
                                                <div>
                                                    <div><?php echo e($block->number); ?></div>
                                                    <small class="text-truncate text-muted">
                                                        <?php echo e(str_limit($block->description, 80)); ?>

                                                    </small>
                                                </div>
                                            </td>

                                            <td class="align-middle text-right">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("edit", \App\Block::class)): ?>
                                                <a href="<?php echo e(route("blocks.edit", $block)); ?>" class="btn btn-sm btn-secondary">
                                                    <i class="fa fa-pencil-alt"></i>
                                                    <span class="sr-only">Edit</span>
                                                </a>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("delete", \App\Block::class)): ?>
                                                <!-- Button trigger modal -->
                                                <a href="#" class="btn btn-sm btn-secondary" data-toggle="modal" data-target="#deleteModal<?php echo e($block->id); ?>">
                                                    <i class="far fa-trash-alt"></i>
                                                    <span class="sr-only">Remove</span>
                                                </a>
                                                
                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal<?php echo e($block->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel<?php echo e($block->id); ?>" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <form action="<?php echo e(route("blocks.destroy", $block)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field("delete"); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="deleteModalLabel<?php echo e($block->id); ?>">Delete item</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    Are you sure you want to delete this item
                                                                </div>
                                                                <div class="modal-footer justify-content-between">
                                                                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-sm btn-danger">Move to trash</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="2">
                                                <div class="my-3">No block yet!</div>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- .pagination -->
                        <?php echo e($blocks->links()); ?>

                        <!-- /.pagination -->
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>