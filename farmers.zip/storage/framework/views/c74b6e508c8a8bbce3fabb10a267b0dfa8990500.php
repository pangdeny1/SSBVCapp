<?php $__env->startSection("content"); ?>
    <div class="wrapper">
        <div class="page">
            <div class="page-inner">
                <header class="page-title-bar">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route("home")); ?>">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i> Dashboard
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">
                                    Settings
                                </a>
                            </li>
                            <li class="breadcrumb-item active">
                                Groups
                            </li>
                        </ol>
                    </nav>

                    <div class="d-sm-flex align-items-sm-center">
                        <h1 class="page-title mr-sm-auto mb-0">
                            Groups
                        </h1>
                        <div class="btn-toolbar">
                            <a href="<?php echo e(route("groups.export")); ?>" class="btn btn-light">
                                <i class="far fa-file-excel"></i>
                                <span class="ml-1">Export as excel</span>
                            </a>
                            
                            <a href="<?php echo e(route("groups.create")); ?>" class="btn btn-primary">
                                <span class="fas fa-plus mr-1"></span>
                                New group
                            </a>
                        </div>
                    </div>
                </header>
                <div class="page-section">
                    <section class="card card-fluid">
                        <header class="card-header">
                            <ul class="nav nav-tabs card-header-tabs">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query("status") ? "" : "active"); ?>"
                                       href="<?php echo e(route("groups.index")); ?>"
                                    >
                                        All
                                    </a>
                                </li>
                            </ul>
                        </header>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <span class="oi oi-magnifying-glass"></span>
                                        </span>
                                    </div>
                                    <form action="">
                                        <input type="text" name="q" class="form-control" placeholder="Search record...">
                                    </form>
                                </div>
                            </div>
                            <div class="text-muted"> Showing <?php echo e($groups->firstItem()); ?> to <?php echo e($groups->lastItem()); ?> of <?php echo e($groups->total()); ?> entries </div>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Product</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($group->name); ?></td>
                                            <td>
                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn btn-sm btn-secondary" data-toggle="modal" data-target="#productModal<?php echo e($group->id); ?>">
                                                    <?php echo e($group->products->count()); ?> product
                                                </button>

                                                <!-- Modal -->
                                                <div class="modal fade" id="productModal<?php echo e($group->id); ?>" tabindex="-1" role="dialog" aria-labelledby="productModalLabel<?php echo e($group->id); ?>" aria-hidden="true">
                                                    <form action="<?php echo e(route("groups.products.store", $group)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="productModalLabel<?php echo e($group->id); ?>">
                                                                        Group product form
                                                                    </h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="form-group">
                                                                        <label>Product</label>
                                                                        <select name="product_id" class="form-control">
                                                                            <option value="">Choose product</option>
                                                                            <?php $__currentLoopData = \App\Product::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($product->id); ?>">
                                                                                <?php echo e($product->name); ?>

                                                                            </option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                    
                                                </div>
                                            </td>   
                                            <td class="align-middle text-right">
                                                
                                                <a href="<?php echo e(route("groups.edit", $group)); ?>" class="btn btn-sm btn-secondary">
                                                    <i class="fa fa-pencil-alt"></i>
                                                    <span class="sr-only">Edit</span>
                                                </a>
                                                
                                                <!-- Button trigger modal -->
                                                <a href="#" class="btn btn-sm btn-secondary" data-toggle="modal" data-target="#deleteModal<?php echo e($group->id); ?>">
                                                    <i class="far fa-trash-alt"></i>
                                                    <span class="sr-only">Remove</span>
                                                </a>
      
                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal<?php echo e($group->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel<?php echo e($group->id); ?>" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <form action="<?php echo e(route("groups.destroy", $group)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field("delete"); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="deleteModalLabel<?php echo e($group->id); ?>">Delete Item</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body text-right">
                                                                    <div class="text-right">Are you sure you want to delete this item</div>
                                                                </div>
                                                                <div class="modal-footer justify-content-between">
                                                                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-sm btn-danger">Move to trash</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php echo e($groups->links()); ?>

                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>