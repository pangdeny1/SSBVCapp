<div class="dropdown">
    <button type="button" class="btn btn-sm btn-light" data-toggle="dropdown">
        <span>More</span>
        <span class="caret"></span>
    </button>

    <div class="dropdown-arrow dropdown-arrow-right"></div>

    <div class="dropdown-menu dropdown-menu-right">
        <?php echo $__env->make("purchases.actions.view", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make("purchases.actions.edit", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="dropdown-divider"></div>
        <?php echo $__env->make("purchases.actions.reject", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make("purchases.actions.complete", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make("purchases.actions.payment_confirm", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make("purchases.actions.remark", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="dropdown-divider"></div>
        <?php echo $__env->make("purchases.actions.delete", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>