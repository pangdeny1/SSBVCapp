<?php $__env->startSection("content"); ?>
    <div class="wrapper">
        <div class="page">
            <div class="page-inner">
                <header class="page-title-bar">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route("home")); ?>">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i> Dashboard
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">
                                    Settings
                                </a>
                            </li>
                            <li class="breadcrumb-item active">
                                Users
                            </li>
                        </ol>
                    </nav>
                    <div class="d-sm-flex align-items-sm-center">
                        <h1 class="page-title mr-sm-auto mb-0">
                            Users
                        </h1>
                        <div class="btn-toolbar">
                            <a href="<?php echo e(route("users.export")); ?>" class="btn btn-light">
                                <i class="far fa-file-excel"></i>
                                <span class="ml-1">Export as excel</span>
                            </a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("create", \App\User::class)): ?>
                            <a href="<?php echo e(route("users.create")); ?>" class="btn btn-primary">
                                <span class="fas fa-plus mr-1"></span>
                                New user
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </header>

                <div class="page-section">
                    <section class="card shadow-1 border-0 card-fluid">
                        <header class="card-header">
                            <ul class="nav nav-tabs card-header-tabs">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query("status") ? "" : "active"); ?>" 
                                        href="<?php echo e(route("users.index")); ?>"
                                    >
                                        All
                                    </a>
                                </li>
                            </ul>
                        </header>

                        <div class="card-body">

                            <div class="text-muted"> Showing <?php echo e($users->firstItem()); ?> to <?php echo e($users->lastItem()); ?> of <?php echo e($users->total()); ?> entries </div>
                            
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th nowrap>Full name</th>
                                            <th nowrap>Phone</th>
                                            <th nowrap>Email</th>
                                            <th nowrap>Roles</th>
                                            <th nowrap>Permissions</th>
                                            <th nowrap></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle" nowrap>
                                                <a href="<?php echo e(route("users.show", $user)); ?>">
                                                    <?php echo e($user->full_name); ?>

                                                </a>
                                            </td>
                                            <td class="align-middle" nowrap><?php echo e($user->phone); ?></td>
                                            <td class="align-middle" nowrap><?php echo e($user->email); ?></td>
                                            <td class="align-middle text-capitalize" nowrap>
                                                <?php echo e($user->roles->count()); ?>

                                                <?php echo e(str_plural("role", $user->roles->count())); ?>

                                            </td>
                                            <td class="align-middle text-capitalize" nowrap>
                                                <?php echo e($user->getAbilities()->count()); ?>

                                                <?php echo e(str_plural("permission", $user->getAbilities()->count())); ?>

                                            </td>
                                            <td class="align-middle text-right" nowrap>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("edit", $user)): ?>
                                                <a href="<?php echo e(route("users.edit", $user)); ?>" class="btn btn-sm btn-secondary">
                                                    <i class="fa fa-pencil-alt"></i>
                                                    <span class="sr-only">Edit</span>
                                                </a>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("delete", $user)): ?>
                                                <a href="javascript:void(0)"
                                                   class="btn btn-sm btn-secondary"
                                                   onclick="event.preventDefault(); document.getElementById('deletion-form-<?php echo e($user->id); ?>').submit();"
                                                >
                                                    <i class="far fa-trash-alt"></i>
                                                    <span class="sr-only">Remove</span>
                                                    <form id="deletion-form-<?php echo e($user->id); ?>"
                                                          action="<?php echo e(route('users.destroy', $user)); ?>"
                                                          method="POST"
                                                          class="d-none"
                                                    >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field("delete"); ?>
                                                    </form>
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- .pagination -->
                            <?php echo e($users->links()); ?>

                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>