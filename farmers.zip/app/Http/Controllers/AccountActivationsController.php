<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AccountActivationsController extends Controller
{
    public function create(Request $request)
    {
        
    }
}
