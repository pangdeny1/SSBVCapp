<?php $__env->startSection("content"); ?>
    
    <div class="wrapper">
        <div class="page">
            <div class="page-inner">
                <header class="page-title-bar">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route("home")); ?>">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i> Dashboard
                                </a>
                            </li>
                            <li class="breadcrumb-item active">
                                Clusters
                            </li>
                        </ol>
                    </nav>

                    <div class="d-sm-flex align-items-sm-center">
                        <h1 class="page-title mr-sm-auto mb-0"> Clusters </h1>
                        <div class="btn-toolbar">
                            <a href="<?php echo e(route("clusters.export")); ?>" class="btn btn-light">
                                <i class="far fa-file-excel"></i>
                                <span class="ml-1">Export as excel</span>
                            </a>
                        </div>
                    </div>
                </header>
                <div class="page-section">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show has-icon">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <div class="alert-icon">
                                <i class="fas fa-info-circle"></i>
                            </div>
                            <strong>Well done!</strong> <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <section class="card card-fluid">
                        <header class="card-header">
                            <ul class="nav nav-tabs card-header-tabs">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query("status") ? "" : "active"); ?>"
                                        href="<?php echo e(route("clusters.index")); ?>"
                                    >
                                        All
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query("status") === "processed" ? "active" : ""); ?>"
                                        href="<?php echo e(route("clusters.index", ["status" => "open"])); ?>"
                                    >
                                        Open
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query("status") === "unprocessed" ? "active" : ""); ?>"
                                        href="<?php echo e(route("clusters.index", ["status" => "active"])); ?>"
                                    >
                                        Active
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link <?php echo e(request()->query("status") === "rejected" ? "active" : ""); ?>"
                                        href="<?php echo e(route("clusters.index", ["status" => "closed"])); ?>">
                                        Closed
                                    </a>
                                </li>
                            </ul>
                        </header>

                        <div class="card-body">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <span class="oi oi-magnifying-glass"></span>
                                    </span>
                                    </div>
                                    <form action="">
                                        <input type="text" name="q" class="form-control" placeholder="Search record...">
                                    </form>
                                </div>
                            </div>

                            <!-- .table-responsive -->
                            <div class="text-muted"> Showing <?php echo e($clusters->firstItem()); ?> to <?php echo e($clusters->lastItem()); ?> of <?php echo e($clusters->total()); ?> entries </div>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th class="text-left"  nowrap>Number</th>
                                        <th class="text-left"  nowrap>Block</th>
                                        <th class="text-left"  nowrap>Group</th>
                                        <th class="text-left"  nowrap>Members</th>
                                        <th class="text-left"  nowrap>Purchases</th>
                                        <th class="text-left"  nowrap>Max</th>
                                        <th class="text-left"  nowrap>Status</th>
                                        <th nowrap="">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $clusters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cluster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td nowrap>
                                                <a href="<?php echo e(route("clusters.purchases.index", $cluster)); ?>" class="user-avatar mr-1">
                                                    <img class="img-fluid"
                                                            src="<?php echo e(Avatar::create($cluster->number)->toBase64()); ?>"
                                                            alt="<?php echo e($cluster->number); ?>"
                                                    >
                                                </a>
                                                <a href="<?php echo e(route("clusters.purchases.index", $cluster)); ?>">
                                                    <?php echo e($cluster->number); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($cluster->block->number); ?></td>
                                            <td><?php echo e(optional($cluster->group)->name); ?></td>
                                            <td>
                                                <?php echo $__env->make("clusters._member_modal", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            </td>
                                            <td>
                                                <?php echo e($cluster->purchases->count()); ?> purchases
                                            </td>
                                            <td><?php echo e($cluster->max_count); ?></td>
                                            <td><?php echo e($cluster->status); ?></td>
                                            <td nowrap="">
                                                <?php if($cluster->max_count > $cluster->farmers->count()): ?>
                                                    <?php if(\App\Farmer::query()->whereNotIn("id", $cluster->farmers->pluck("id"))->exists()): ?>
                                                        <?php echo $__env->make("clusters._farmers_modal", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button type="button" class="btn btn-sm btn-primary">
                                                        Batch is full
                                                    </button>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">
                                                <p class="my-4">No Batch available yet!</p>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- .pagination -->
                            <?php echo e($clusters->links()); ?>

                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>