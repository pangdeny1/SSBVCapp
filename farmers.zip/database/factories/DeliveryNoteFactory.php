<?php

use Faker\Generator as Faker;

$factory->define(App\DeliveryNote::class, function (Faker $faker) {
    return [
        //
    ];
});
